const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const acorn=require('./acorn.cjs');
const target=process.argv[2]||path.join(__dirname,'main.js');
const backup=target+'.original';if(!fs.existsSync(backup))fs.copyFileSync(target,backup);
const source=fs.readFileSync(backup,'utf8'),map=JSON.parse(fs.readFileSync(path.join(__dirname,'vi.json'),'utf8'));
const tokens=[...acorn.tokenizer(source,{ecmaVersion:'latest'})],edits=[];
for(let i=0;i<tokens.length;i++){
 const t=tokens[i];if(t.start<71000||(t.start>108000&&t.start<147000)||!['string','template'].includes(t.type.label)||map[t.value]===undefined)continue;
 if(tokens[i+1]?.type.label===':'&&['{',',','case'].includes(tokens[i-1]?.type.label))continue;
 if(tokens[i-1]?.type.label==='('&&tokens[i-2]?.value==='de')continue;
 const vi=map[t.value],content=t.type.label==='string'?JSON.stringify(vi):vi.replace(/\\/g,'\\\\').replace(/`/g,'\\`').replace(/\$\{/g,'\\${');edits.push({start:t.start,end:t.end,content});
}
let result=source;for(const e of edits.reverse())result=result.slice(0,e.start)+e.content+result.slice(e.end);
const signature=s=>[...acorn.tokenizer(s,{ecmaVersion:'latest'})].map(t=>['string','template'].includes(t.type.label)?t.type.label:[t.type.label,t.value]);assert.deepEqual(signature(source),signature(result));
const localeKeys=['Default:','Error:','missing default light value, or value is not in a valid color format','missing default dark value, or value is not in a valid color format','missing default value, or value is not in a valid color format','missing default value'];
const locale=Object.fromEntries(localeKeys.map(k=>[k,map[k]]));
function once(from,to){assert.equal(result.split(from).length,2,'Expected one patch boundary: '+from);result=result.replace(from,to);}
once('pl={ar:ei','pl={vi:'+JSON.stringify(locale)+',ar:ei');
once('function ve(e){return ct&&e[`title.${ct}`]||e.title}','function ve(e){return styleSettingsViLabel(e["title.vi"]||ct&&e[`title.${ct}`]||e.title)}');
once('function me(e){return ct&&e[`description.${ct}`]||e.description}','function me(e){return styleSettingsViLabel(e["description.vi"]||ct&&e[`description.${ct}`]||e.description)}');
once('c.addOption(f,f):c.addOption(f.value,f.label)','c.addOption(f,styleSettingsViLabel(f)):c.addOption(f.value,styleSettingsViLabel(f.label))');
assert.equal(result.split('return typeof t=="string"?t:t.label').length,3);
result=result.replaceAll('return typeof t=="string"?t:t.label','return styleSettingsViLabel(typeof t=="string"?t:t.label)');
once('document.createTextNode(t||n)','document.createTextNode(styleSettingsViLabel(t||n))');
result+='\nfunction styleSettingsViLabel(value){if(typeof value!=="string")return value;const translations='+JSON.stringify(map)+';return translations[value]||value;}\n// Style Settings Vietnamese interface v2\n';
acorn.parse(result,{ecmaVersion:'latest'});
// Keep persisted section IDs, CSS variables, storage access and command IDs identical.
for(const regex of [/setSetting\([^)]*\)/g,/getSetting\([^)]*\)/g,/clearSetting\([^)]*\)/g,/id:"show-style-settings-leaf"/g])assert.deepEqual(source.match(regex),result.match(regex));
fs.writeFileSync(target,result);fs.writeFileSync(path.join(__dirname,'translation-report.json'),JSON.stringify({translatedStaticStrings:edits.length,hasVietnameseLocale:true,pdfStyleLabelsTranslated:map['Highlights'],storageAndCommandIdsPreserved:true},null,2)+'\n');console.log(JSON.stringify({translations:edits.length,locale:'vi',syntax:'OK',storageUnchanged:true}));
