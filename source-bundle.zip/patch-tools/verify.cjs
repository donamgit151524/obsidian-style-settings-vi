const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path'),assert=require('node:assert/strict');
const s=fs.readFileSync(path.join(__dirname,'main.js'),'utf8');
const helper=s.slice(s.indexOf('\nfunction styleSettingsViLabel'));
const ctx={ct:'vi'};
// Test actual title/description resolvers without a running Obsidian instance.
const title=s.slice(s.indexOf('function ve(e)'),s.indexOf('function Ct(e)'));
const resolvers=vm.runInNewContext(helper+';'+title+';({ve,me,styleSettingsViLabel})',ctx);
const setting={id:'pdf-plus-highlight-opacity',type:'variable-number-slider',title:'Highlight opacity',description:'Boldness of highlights (em)',default:0.2};
const before=JSON.stringify(setting);
assert.equal(resolvers.ve(setting),'Độ đậm của màu tô sáng');assert.equal(resolvers.me(setting),'Độ dày của vùng tô sáng (em)');assert.equal(JSON.stringify(setting),before);
assert.equal(resolvers.styleSettingsViLabel('A custom theme label'),'A custom theme label');
const css=fs.readFileSync(path.resolve(__dirname,'../plugins/pdf-plus/styles.css'),'utf8');
const block=css.match(/\/\*\s*@settings[\s\S]*?\*\//)[0];
let checked=0;for(const m of block.matchAll(/^\s*(title|description): (.+)$/gm)){assert.notEqual(resolvers.styleSettingsViLabel(m[2]),m[2],m[2]);checked++;}
for(const language of ['en',null,'vi']){ctx.ct=language;assert.equal(resolvers.ve(setting),'Độ đậm của màu tô sáng');}ctx.ct='vi';
assert.equal(resolvers.ve({...setting,'title.vi':'Tiêu đề riêng'}),'Tiêu đề riêng');
assert(s.includes('pl={vi:'));assert(s.includes('name:"Mở khung cài đặt giao diện"'));
console.log(JSON.stringify({pdfMetadataLabels:checked,valuesAndIdsUnchanged:true,popoutLocaleFallback:true,commandTranslated:true}));
